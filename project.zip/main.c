#include"Application\application.c"
int main()
{
app_start();
return 0;
}