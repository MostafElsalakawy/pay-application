#ifndef app_h
#define app_h
#include"..\Card\card.h"
#include"..\terminal\terminal.h"
ST_cardData_t *carddata,card_data;
ST_terminalData_t *termdata,term_data;
int app_start();
#endif